

#!/bin/env python

import board
import busio
import adafruit_mcp4725
import time
import sys as exit

i2c = busio.I2C(board.SCL, board.SDA)
dim = adafruit_mcp4725.MCP4725(i2c,address=0x60 )
cct = adafruit_mcp4725.MCP4725(i2c, address=0x62)

dim.raw_value = 0
cct.raw_value = 0
i = 0
j = 0
levelB = 0
levelC = 0
while True:
        x = input('type b for brightness and c for color: ')
        if(x == 'b'):
            flag = 0
            while(flag == 0):
                y = input('type w to increase voltage and s to decrease, type x to go back: ')
                if(y == 'w' and levelB < 8):
                    i = i + 511
                    dim.raw_value = i
                    levelB = levelB + 1
                    print(levelB)
                elif(y == 's' and levelB > 0):
                    i = i - 511
                    dim.raw_value = i
                    levelB = levelB - 1
                    print(levelB)
                elif(y == 'x'):
                   flag = 1
                else:
                    print('Please enter a valid command')
        elif(x == 'c'):
            flag = 0
            while(flag == 0):
                y = input('type w to increase voltage and s to decrease, type x to go back: ')
                if(y == 'w' and levelC < 8):
                    j = j + 511
                    cct.raw_value = j
                    levelC = levelC + 1
                    print(levelC)
                elif(y == 's' and levelC > 0):
                    j = j - 511
                    cct.raw_value = j
                    levelC = levelC -1
                    print(levelC)
                elif(y == 'x'):
                   flag = 1
                else:
                    print('Please enter a valid command')
        else:
            print('Please enter either b or c')

