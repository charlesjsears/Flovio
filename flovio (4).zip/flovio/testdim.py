

#!/bin/env python

import board
import busio
import adafruit_mcp4725
import time
import sys as exit

i2c = busio.I2C(board.SCL, board.SDA)
dim = adafruit_mcp4725.MCP4725(i2c,address=0x60 )
cct = adafruit_mcp4725.MCP4725(i2c, address=0x62)



while True:
	dim.raw_value = 0
	cct.raw_value = 0
	print("Beginning Pulse")
	time.sleep(2)
	for i in range(1023):
		dim.raw_value = (i*4)
		cct.raw_value = (i*4)
		print(dim.value)
		print(cct.value)
		time.sleep(0.01)
	for i in range(1023, 0, -1):
		dim.raw_value = (i*4)
		cct.raw_value = (i*4)
		print(dim.value)
		print(cct.value)
		time.sleep(0.01)
	break
